# Publicar ACEAI Studio en GitHub Pages

El archivo `index.html` es tu app completa (un solo archivo, con tu logo y los 3 idiomas).
GitHub Pages sirve `index.html` automáticamente, así que publicarlo es muy rápido.

> Nota importante: GitHub Pages **solo sirve archivos estáticos**. La app se verá perfecta y
> podrás navegar todo, pero la generación con IA funcionará en **modo demo** (ejemplos de muestra).
> Para que la IA genere de verdad, despliega el backend en Vercel o Cloudflare (ver `README.md`
> del backend) y pega su URL en la línea `const API_ENDPOINT = ""` dentro de `index.html`.

---

## Método 1 — Sin instalar nada (desde la web, 2 minutos)

1. Entra en https://github.com e inicia sesión (o crea una cuenta gratis).
2. Arriba a la derecha: **+ → New repository**.
   - Repository name: por ejemplo `aceai-studio`
   - Marca **Public**
   - Crea el repositorio (**Create repository**).
3. En la página del repo vacío, pulsa **uploading an existing file**
   (o ve a **Add file → Upload files**).
4. Arrastra tu archivo **`index.html`** a la zona de subida.
5. Abajo, pulsa **Commit changes**.
6. Ve a **Settings** (del repo) → en el menú izquierdo, **Pages**.
7. En **Source**, elige **Deploy from a branch**.
   - Branch: **main** · carpeta: **/ (root)** → **Save**.
8. Espera ~1 minuto. GitHub te mostrará la URL pública, del tipo:

       https://TU-USUARIO.github.io/aceai-studio/

¡Listo! Esa es tu app en línea. Cada vez que subas un `index.html` nuevo, se actualiza sola.

---

## Método 2 — Con git (si lo usas desde tu computadora)

```bash
# dentro de una carpeta con tu index.html
git init
git add index.html
git commit -m "ACEAI Studio"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/aceai-studio.git
git push -u origin main
```

Luego activa Pages en **Settings → Pages → Deploy from a branch → main / root**.

---

## Conectar la IA real (opcional, recomendado)

1. Despliega el backend siguiendo el `README.md` del backend (Vercel o Cloudflare Worker).
2. Copia la URL de tu backend (p. ej. `https://aceai.tu-cuenta.workers.dev`).
3. Abre `index.html`, busca:

       const API_ENDPOINT = "";

   y ponla así:

       const API_ENDPOINT = "https://aceai.tu-cuenta.workers.dev";

4. Vuelve a subir `index.html` a tu repo. Ahora la generación con IA funciona en tu web publicada.

---

## Dominio propio (opcional)

En **Settings → Pages → Custom domain** puedes poner tu propio dominio
(p. ej. `studio.aceaionlinemarketing.com`) y seguir las instrucciones de DNS que te muestre GitHub.
